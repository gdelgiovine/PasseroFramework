using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Collections.Generic;
using Scriban;
using Mono.TextTemplating;
using System.Threading.Tasks;

namespace PasseroCodeGen.Core
{
    public class Model
    {
        public string Namespace { get; set; } = "PasseroDemo";
        public List<Entity> Entities { get; set; } = new();
    }

    public class Entity
    {
        public string Name { get; set; } = "";
        public List<Property> Properties { get; set; } = new();
    }

    public class Property
    {
        public string Name { get; set; } = "";
        public string Type { get; set; } = "string";
    }

    public static class ResourceHelper
    {
        public static string ReadEmbedded(string resourcePath)
        {
            var asm = Assembly.GetExecutingAssembly();
            var full = asm.GetManifestResourceNames().FirstOrDefault(n => n.EndsWith(resourcePath.Replace("/", ".")));
            if (full == null) throw new InvalidOperationException($"Resource not found: {resourcePath}");
            using var s = asm.GetManifestResourceStream(full)!;
            using var r = new StreamReader(s, Encoding.UTF8);
            return r.ReadToEnd();
        }
    }

    public class ScribanGenerator
    {
        public string Render(string templateResourcePath, Model model)
        {
            var text = ResourceHelper.ReadEmbedded(templateResourcePath);
            var tmpl = Template.Parse(text);
            if (tmpl.HasErrors) throw new Exception(string.Join("\n", tmpl.Messages));
            return tmpl.Render(model, member => member.Name);
        }
    }

    public class T4Generator
    {
        public async Task<string> TransformAsync(string templateResourcePath, Model model)
        {
            var t4 = new TemplateGenerator();
            var session = new Microsoft.VisualStudio.TextTemplating.TextTemplatingSession();
            session["Model"] = model;

            string content = ResourceHelper.ReadEmbedded(templateResourcePath);

            // Mono.TextTemplating host config
            var host = new CustomT4Host();
            host.Session = session;

            string output = await host.ProcessTemplateAsync("InMemory.tt", content);
            if (host.Errors.HasErrors)
            {
                throw new Exception(string.Join("\n", host.Errors.Cast<System.CodeDom.Compiler.CompilerError>().Select(e => e.ToString())));
            }
            return output;
        }
    }

    // Minimal host for Mono.TextTemplating
    public class CustomT4Host : TemplateGenerator
    {
        public Microsoft.VisualStudio.TextTemplating.ITextTemplatingSession? Session { get; set; }
        public async Task<string> ProcessTemplateAsync(string name, string content)
        {
            using var input = new StringReader(content);
            using var output = new StringWriter();
            await this.ProcessTemplateAsync(name, input, output);
            return output.ToString();
        }
    }

    public static class SampleModels
    {
        public static Model LoadDefault()
        {
            var json = ResourceHelper.ReadEmbedded("Templates/Samples/sample-model.json");
            return System.Text.Json.JsonSerializer.Deserialize<Model>(json, new System.Text.Json.JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            })!;
        }
    }

    public class CodeGenService
    {
        public async Task<Dictionary<string, string>> GenerateAllAsync(Model? model = null)
        {
            model ??= SampleModels.LoadDefault();

            var outputs = new Dictionary<string, string>();

            var scriban = new ScribanGenerator();
            outputs["ViewModels/GeneratedViewModels.cs"] = scriban.Render("Templates/scriban/viewmodels.sbn", model);
            outputs["Forms/GeneratedForms.cs"] = scriban.Render("Templates/scriban/forms.sbn", model);

            var t4 = new T4Generator();
            outputs["Models/GeneratedEntities.cs"] = await t4.TransformAsync("Templates/t4/Entity.tt", model);

            return outputs;
        }
    }
}
