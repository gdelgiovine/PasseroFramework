# Passero CodeGen VSIX (Scriban + T4)

Estensione Visual Studio 2022 che aggiunge il comando **Tools → Generate Wisej Code (Scriban/T4)**.
Il comando genera classi **Models** via T4 e **ViewModels/Forms** via **Scriban**, usando un modello di esempio.

## Requisiti
- Visual Studio 2022 (17.x)
- SDK .NET Framework 4.7.2 (per il progetto VSIX)
- NuGet ripristinerà: `Microsoft.VSSDK.BuildTools`, `Scriban`, `Mono.TextTemplating`

## Progetti
- **PasseroCodeGen.Core** (netstandard2.0): logica di generazione, template incorporati
- **PasseroCodeGen.VSIX** (net472): pacchetto estensione e comando menù

## Come provare
1. Apri `PasseroCodeGen.VSIX.sln`.
2. Imposta **PasseroCodeGen.VSIX** come progetto di avvio e avvia in modalità *Experimental Instance*.
3. In VS sperimentale, apri una Solution qualsiasi (o creane una vuota).
4. Menù **Tools → Generate Wisej Code (Scriban/T4)**: i file compariranno in `./Generated` sotto la solution aperta.

## Adattare ai tuoi modelli
- Sostituisci `Templates/Samples/sample-model.json` con il tuo modello (o modifica `CodeGenService.GenerateAllAsync` per leggere un tuo file). 
- Modifica gli script:
  - **Scriban**: `Templates/scriban/viewmodels.sbn`, `Templates/scriban/forms.sbn`
  - **T4**: `Templates/t4/Entity.tt` (usa `Session["Model"]`).

> Nota: questa bozza dimostra come integrare **entrambi** gli engine nella stessa estensione.
> Possiamo collegarla alle tue classi reali (Authors/Titles/Publishers) nel prossimo passaggio.
