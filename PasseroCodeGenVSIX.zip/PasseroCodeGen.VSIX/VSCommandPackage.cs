using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using Task = System.Threading.Tasks.Task;
using PasseroCodeGen.Core;
using System.IO;

namespace PasseroCodeGen.VSIX
{
    [PackageRegistration(UseManagedResourcesOnly = true, AllowsBackgroundLoading = true)]
    [InstalledProductRegistration("#110", "#112", "1.0")]
    [Guid("d36bbdf3-b704-4e2c-9d71-78c6bfca2b1f")]
    [ProvideMenuResource("Menus.ctmenu", 1)]
    public sealed class VSCommandPackage : AsyncPackage
    {
        protected override async Task InitializeAsync(CancellationToken cancellationToken, IProgress<ServiceProgressData> progress)
        {
            await base.InitializeAsync(cancellationToken, progress);
            await GenerateCommand.InitializeAsync(this);
        }
    }

    internal sealed class GenerateCommand
    {
        public const int CommandId = 0x0100;
        public static readonly Guid CommandSet = new Guid("6d9745d9-a952-434e-b77c-90a1114f4027");
        private readonly AsyncPackage package;

        private GenerateCommand(AsyncPackage package, OleMenuCommandService commandService)
        {
            this.package = package ?? throw new ArgumentNullException(nameof(package));
            var cmdID = new CommandID(CommandSet, CommandId);
            var menuItem = new OleMenuCommand(this.ExecuteAsync, cmdID);
            commandService.AddCommand(menuItem);
        }

        public static async Task InitializeAsync(AsyncPackage package)
        {
            // Add our command handlers for menu (commands must exist in the .vsct file)
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(package.DisposalToken);
            var commandService = await package.GetServiceAsync(typeof(IMenuCommandService)) as OleMenuCommandService;
            _ = new GenerateCommand(package, commandService!);
        }

        private async void ExecuteAsync(object sender, EventArgs e)
        {
            try
            {
                await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();
                var dte = (EnvDTE.DTE)await package.GetServiceAsync(typeof(EnvDTE.DTE));
                string? solutionDir = Path.GetDirectoryName(dte.Solution?.FullName ?? string.Empty);
                if (string.IsNullOrEmpty(solutionDir))
                {
                    VsShellUtilities.ShowMessageBox(package, "Apri prima una Solution.", "Passero CodeGen", OLEMSGICON.OLEMSGICON_WARNING, OLEMSGBUTTON.OLEMSGBUTTON_OK, OLEMSGDEFBUTTON.OLEMSGDEFBUTTON_FIRST);
                    return;
                }

                string outDir = Path.Combine(solutionDir, "Generated");
                Directory.CreateDirectory(outDir);

                var svc = new CodeGenService();
                var outputs = await svc.GenerateAllAsync();

                foreach (var kv in outputs)
                {
                    string path = Path.Combine(outDir, kv.Key);
                    Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                    File.WriteAllText(path, kv.Value);
                }

                VsShellUtilities.ShowMessageBox(package, $"File generati in:\n{outDir}", "Passero CodeGen", OLEMSGICON.OLEMSGICON_INFO, OLEMSGBUTTON.OLEMSGBUTTON_OK, OLEMSGDEFBUTTON.OLEMSGDEFBUTTON_FIRST);
            }
            catch (Exception ex)
            {
                VsShellUtilities.ShowMessageBox(package, ex.ToString(), "Passero CodeGen - Errore", OLEMSGICON.OLEMSGICON_CRITICAL, OLEMSGBUTTON.OLEMSGBUTTON_OK, OLEMSGDEFBUTTON.OLEMSGDEFBUTTON_FIRST);
            }
        }
    }
}
